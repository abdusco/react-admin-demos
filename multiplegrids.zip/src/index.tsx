import React from 'react';
import ReactDOM from 'react-dom';
import App from './ReactAdmin';

ReactDOM.render(
    <App />,
    document.getElementById('root')
);

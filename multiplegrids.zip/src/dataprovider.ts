import jsonServerProvider from 'ra-data-json-server';

const jsondp = jsonServerProvider('https://jsonplaceholder.typicode.com' );

export default jsondp;

/// <reference types="react-scripts" />

declare module 'react-redux';
declare module 'lodash/get';